package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightTrackerDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int VERSION = 1;


    public WeightTrackerDB(Context context) {
        super(context,
                DATABASE_NAME,
                null,
                VERSION);
    }

    private static final class WeightTables {
        private static final String TABLE1 = "Users";
        private static final String COL_UName = "Username";
        private static final String COL_UPwd = "Password";

        private static final String TABLE2 = "Weight_History";
        private static final String COL_UName2 = "Username2";
        private static final String COL_Date = "Date";
        private static final String COL_Dweight = "Daily_Weight";

        private static final String TABLE3 = "Goal";
        private static final String COL_GWieght = "Goal_Weight";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("drop table if exists " + WeightTables.TABLE1);
        db.execSQL("drop table if exists " + WeightTables.TABLE2);
        db.execSQL("drop table if exists " + WeightTables.TABLE3);
        db.execSQL("create table " + WeightTables.TABLE1 + " (" +
                WeightTables.COL_UName + " text primary key, " + WeightTables.COL_UPwd + " text) ");

        db.execSQL("create table " + WeightTables.TABLE2 + " (" +
                WeightTables.COL_UName2 + " text, " +
                WeightTables.COL_Date + " text, " + WeightTables.COL_Dweight + " text) ");

        db.execSQL("create table " + WeightTables.TABLE3 + " (" +
                WeightTables.COL_UName + " text, " +
                WeightTables.COL_GWieght + " text) ");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + WeightTables.TABLE1);
        db.execSQL("drop table if exists " + WeightTables.TABLE2);
        db.execSQL("drop table if exists " + WeightTables.TABLE3);
        onCreate(db);
    }
    public boolean verify(String name, String pwd) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"Username"};
        // db = openDatabase();

        String selection = "Username=? and Password = ?";
        String[] selectionArgs = {name, pwd};

        Cursor cur = db.query(WeightTables.TABLE1, columns, selection, selectionArgs, null, null, null);
        //Cursor cur = db.rawQuery("SELECT * FROM " + WeightTables.TABLE + " where " + WeightTables.COL_UName + "='" + name + "'" + " and " + WeightTables.COL_UName  + "='" + pwd + "'",null);
        int count = cur.getCount();
        if(count > 0)
            return true;
        else
            return false;
    }
    public boolean UsernameExists(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"Username"};
        String selection = "Username=? COLLATE NOCASE";
        String[] selectionArgs = {name};

        Cursor cur = db.query(WeightTables.TABLE1, columns, selection, selectionArgs, null, null, null);
        //Cursor cur = db.rawQuery("SELECT * FROM " + WeightTables.TABLE + " where " + WeightTables.COL_UName + "='" + name + "'" + " and " + WeightTables.COL_UName  + "='" + pwd + "'",null);
        int count = cur.getCount();
        if(count > 0)
            return true;
        else
            return false;
    }
    public boolean verifyWeight(String luser, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"Username2"};
        // db = openDatabase();

        String selection = "Username2=? and Date = ?";
        String[] selectionArgs = {luser, date};

        Cursor cur = db.query(WeightTables.TABLE2, columns, selection, selectionArgs, null, null, null);
        //Cursor cur = db.rawQuery("SELECT * FROM " + WeightTables.TABLE + " where " + WeightTables.COL_UName + "='" + name + "'" + " and " + WeightTables.COL_UName  + "='" + pwd + "'",null);
        int count = cur.getCount();
        if(count > 0)
            return true;
        else
            return false;
    }
    public boolean deleteWeight(String luser, String date, String weight){
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = "Username2=? and Date = ? and Daily_Weight = ?";
        String[] selectionArgs = {luser, date, weight};
        long result = db.delete(WeightTables.TABLE2,selection,selectionArgs);
        if (result > 0)
            return true;
        else
            return false;
    }

    public Cursor dailyWeights(String luser) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"Username2, Date, Daily_Weight"};
        // db = openDatabase();

        String selection = "Username2=?";
        String[] selectionArgs = {luser};

        Cursor cur = db.query(WeightTables.TABLE2, columns, selection, selectionArgs, null, null, null);
        //Cursor cur = db.rawQuery("SELECT * FROM " + WeightTables.TABLE + " where " + WeightTables.COL_UName + "='" + name + "'" + " and " + WeightTables.COL_UName  + "='" + pwd + "'",null);
        return cur;
    }
    public boolean insertUser(String name, String pwd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(WeightTables.COL_UName, name);
        contentValues.put(WeightTables.COL_UPwd, pwd);

        long result = db.insert(WeightTables.TABLE1, null, contentValues);

        if(result==-1)
            return false;
        else
            return true;

    }
    public boolean insertWeight(String luser, String date, String wgt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(WeightTables.COL_UName2, luser);
        contentValues.put(WeightTables.COL_Date, date);
        contentValues.put(WeightTables.COL_Dweight, wgt);

        long result = db.insert(WeightTables.TABLE2, null, contentValues);

        if(result==-1)
            return false;
        else
            return true;

    }
    public boolean updateWeight(String luser, String date, String wgt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        //contentValues.put(WeightTables.COL_UName, luser);
        //contentValues.put(WeightTables.COL_Date, date);
        contentValues.put(WeightTables.COL_Dweight, wgt);

        String selection = "Username2=? and Date = ?";
        String[] selectionArgs = {luser, date};

        long result = db.update(WeightTables.TABLE2,contentValues,selection,selectionArgs);

        if(result==-1)
            return false;
        else
            return true;

    }
}


