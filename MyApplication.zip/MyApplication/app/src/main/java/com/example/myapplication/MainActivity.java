package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
// This class performs the login and create user account functions and it is invoked as first class when app is loaded.
public class MainActivity extends AppCompatActivity {
    WeightTrackerDB myDB;
    EditText editUName, editUPWD;
    Button btnLogin, btnAdd;

    // It will be called while loading the login page and initializes the database, fields and calls methods
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDB = new WeightTrackerDB(this);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        editUName = (EditText) findViewById(R.id.editUsername);
        editUPWD = (EditText) findViewById(R.id.editPwd);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        Login();
        AddUser();

    }

    // Create new user account when username is not taken over
    public void AddUser() {
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uname = editUName.getText().toString().trim();
                String pwd = editUPWD.getText().toString().trim();
                if (!uname.isEmpty()){
                    boolean IsUsernameTaken = myDB.UsernameExists(uname);
                    if (!IsUsernameTaken && !pwd.isEmpty() && pwd.length() >6) {
                        boolean isInserted = myDB.insertUser(uname, pwd);
                        if (isInserted)
                            Toast.makeText(MainActivity.this, "New user is created successfully", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, "New user creation is not successful", Toast.LENGTH_LONG).show();
                    } else
                        Toast.makeText(MainActivity.this, "Username is not available. Please try a new username", Toast.LENGTH_LONG).show();
                }else
                    Toast.makeText(MainActivity.this, "Username is empty. Please enter username and try again", Toast.LENGTH_LONG).show();


            }
        });
    }

    // Checks the username and password entered and login into the app
    public void Login() {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "on click", Toast.LENGTH_LONG).show();
                boolean match = myDB.verify(editUName.getText().toString(), editUPWD.getText().toString());
                if (match) {
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("user", editUName.getText().toString());
                    startActivity(intent);
                } else
                    Toast.makeText(MainActivity.this, "Username/password is wrong", Toast.LENGTH_LONG).show();

            }
        });
    }
}
/*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void logout() {
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
}*/